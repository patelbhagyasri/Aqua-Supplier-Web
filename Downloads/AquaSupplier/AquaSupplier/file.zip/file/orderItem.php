<?php
ini_set('session.cache_limiter','public');
session_cache_limiter(false);

include_once('connection.php');
date_default_timezone_set("Asia/Calcutta");

if (!isset($_SESSION['name'])) {
	echo "<script>window.location='index.php'</script>";	
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Add New Product</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<link rel="stylesheet" href="bootstrap/css/w3.css">
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<script src="bootstrap/js/jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="bootstrap/js/jquery-ui.js" type="text/javascript"></script>
<script src="bootstrap/js/jquery-ui.min.js" type="text/javascript"></script>
<link href="bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css" />
	<script src="bootstrap/js/bootstrap3-typeahead.min.js"></script> 
	<style>
		.mar{
		margin-top:20px;
		}
		input{
		
    text-transform: uppercase;

		}
	</style>
	<style>
@media screen and (max-width: 455px) {
    .h3 {
        font-size:16px;
    }
}

.modal-header, .close {
      background-color:#bce8f1 !important;
    
     
  }
</style>
	<style>
		.mar{
		margin-top:20px;
		}
		input{
		
    text-transform: uppercase;

		}
	</style>

<script type="text/javascript">
	
     $(function() {
			//var picdate={dateFormate:"yy-mm-dd"};
			$( "#txtStartDate" ).datepicker(
			//{dateFormat:"yy MM dd  "
			//}
			);
  });
  
     $(function() {
			//var picdate={dateFormate:"yy-mm-dd"};
			$( "#txtEndDate" ).datepicker(
			//{dateFormat:"yy MM dd  "
			//}
			);
  });
  

</script>
</head>
<body style="background:#e6e6e6;color:black;">
<?php
	include('sidebarHeader.php');
?>

<form action="" method="POST">
<div id="main" style="margin-left:200px">

<div class="w3-container w3-display-container">

		<span title="open Sidebar" style="display:none" id="openNav" class="w3-button w3-transparent w3-display-topleft w3-xlarge" onclick="w3_open()">&#9776;</span>
	<div class="modal-content" style="margin-top:50px;">
	<?php
					$result=mysql_query("select * from generate_invoice where invoice_id='".$_REQUEST['invoiceID']."'");
					while($row=mysql_fetch_array($result))
					{
						$name=$row['cname'];
						$contact=$row['ccontact'];
						$address=$row['address1'];
						$invoiceDate=$row['invoice_date'];
						$orderDate=$row['order_date'];
						$invoiceID=$row['invoice_id'];
					}
					$resFinal=mysql_query("select * from final_invoice where invoice_id='".$_REQUEST['invoiceID']."'");
					while($rowFinal=mysql_fetch_array($resFinal))
					{
						$orderStatus=$rowFinal['order_status'];
					}
	?>
        <div class="modal-header">
			<header class="w3-container w3-blue text-center">
				
				<div class="w3-row">
					  <div class="w3-col m7 w3-center">
						<b style="font-size:25px;"><?php echo $name;?></b>
					  </div>
					   <div class="w3-col m2 w3-center">
						<?php
							if($orderStatus=="Pending")
							{
						?>
						<input type="submit" class="w3-button w3-light-blue"  name="btnConfirm" onclick="return confirm('Are You Sure?')" value="Confirm Order">
						<?php
							}
							else
							{
								?>
								<p type="submit" class="w3-button w3-green" value="" >delivered</p>
								<?php
							}
						?>
					  </div>
					  <div class="w3-col m3 w3-center">
						invoice No: <b style="font-size:15px;"><?php echo $invoiceID;?></b>
					  </div>
					 
					</div>
				<hr>
				  
				  <div class="w3-row">
					  <div class="w3-col m3 w3-center">
						Address:<b style="font-size:15px;"><?php echo $address;?></b>
					  </div>
					  <div class="w3-col m3 w3-center">
						Contact No: <b style="font-size:15px;"><?php echo $contact;?></b>
					  </div>
					  <div class="w3-col m3 w3-center">
						Invoice Date: <b style="font-size:15px;"><?php echo $invoiceDate;?></b>
					  </div>
					  <div class="w3-col m3 w3-center">
						Order Date: <b style="font-size:15px;"><?php echo $orderDate;?></b>
					  </div>
					</div>
			</header>
		
        </div>
		<div class="modal-body" style="padding:10px 10px;">
		<div class="row">
	
		
		
		<div class="col-sm-12">
		<div class="w3-responsive">
			<table class="w3-table-all w3-hoverable">
				<thead>
				  <tr class="w3-light-grey">
					<th>#</th>
					<th>Product</th>
					<th>Qty</th>
					<th>Rate</th>
					<th>Amount</th>
				  </tr>
				</thead>
				<?php
					$resTemp=mysql_query("select * from temp_invoice where invoice_id='".$_REQUEST['invoiceID']."'");
					while($rowTemp=mysql_fetch_array($resTemp))
					{
						?>
						<tr>
							  <td><?php echo ++$count; ?></td>
							  <td><?php echo $rowTemp['product_name'] ?></td>
							  <td><?php echo $rowTemp['product_qty'] ?></td>
							  <td><?php echo $rowTemp['product_rate'] ?></td>
							  <td><?php echo $rowTemp['amount'] ?></td>
							  
							</tr>
						<?php
					}
				?>
				<?php
							$rrr=mysql_query("select sum(amount),sum(debit) from statement where invoice_id='$invoiceID'");
							
							while($fetchRow=mysql_fetch_array($rrr))
							{
								$totalDue=$fetchRow[0]-$fetchRow[1];
							}
						?>
						
				<?php
							$resDeposite=mysql_query("select sum(debit) from statement where invoice_id='".$_REQUEST['invoiceID']."' and remark='Deposite' and status='Paid'");
							
							while($rowDeposite=mysql_fetch_array($resDeposite))
							{
								$totalDeposite=$rowDeposite[0];
							}
						?>
						
						<?php
							$resSum=mysql_query("select sum(amount) from temp_invoice where invoice_id='".$_REQUEST['invoiceID']."'");
					while($rowSum=mysql_fetch_array($resSum))
						{
							$totalSum=$rowSum[0];
						}
						?>
			 </table>
			 <div class="w3-center" style="margin-top:5px;">
			 <div class="w3-container">
				  <div class="w3-bar">
					  <button class="w3-button w3-black"> Deposite Amount : <?php echo $totalDeposite; ?> </button>
					  <button class="w3-button w3-black"> Invoice Amount : <?php echo $totalSum; ?></button>
					  <button class="w3-button w3-black"> Total Due: <?php echo $totalDue; ?></button>
					</div> 
				  
					
			</div>
			</div>
			<div class="col-sm-12">
				<div class="w3-responsive">
					<div class="w3-center w3-panel w3-topbar w3-bottombar w3-border-green w3-pale-red" style="margin-top:5px;">
						Order Statement
					</div>
					<table class="w3-table-all w3-hoverable w3-small">
											<tr>
												<th>Bill No</th>
												<th>Name</th>
												
												<th>Contact</th>
												<th>Address</th>
												<th>Date</th>
												<th>Bill Amount</th>
												<th>Credit</th>
												<th>Debit</th>
												<th>Remark</th>
												<th>Status</th>
												<th>Action</th>
												
											</tr>
											
												<?php
												$resStatement1=mysql_query("select ge.invoice_id,ge.cname,ge.ccontact,ge.address1,st.st_date,st.amount,st.credit,st.debit,st.remark,st.status,st.st_id from generate_invoice ge,statement st where ge.invoice_id=st.invoice_id and st.invoice_id='".$_REQUEST['invoiceID']."'");				
												while($rowStP=mysql_fetch_array($resStatement1))
												{
												?>
													
												
														
													<tr>
													<td><?php echo $rowStP[0]; ?></td>
													<td><?php echo $rowStP[1]; ?></td>							
													<td><?php echo $rowStP[2]; ?></td>
													<td><?php echo $rowStP[3]; ?></td>
													<td><?php echo date('d-M-Y',strtotime($rowStP[4])); ?></td>
													<td><?php echo $rowStP[5]; ?></td>
													<td><?php echo $rowStP[6]; ?></td>
													<td><?php echo $rowStP[7]; ?></td>
													<td><?php echo $rowStP[8]; ?></td>
													<td><?php echo $rowStP[9]; ?></td>
													<td><center><a href="?deleteID=<?php echo $rowStP[10]; ?>&invoiceID=<?php echo $_REQUEST['invoiceID']; ?>" onClick="return confirm('Are You Sure?')" class="btn btn-sm btn-danger"> <i class="glyphicon glyphicon-trash"></i> </a></center></td>
														
													
													</tr>
												<?php
													
													
												}
											?>
											
										</table>
									</div>
				</div>
			</div>
		</div>
		</div>
		</div>
		</div>
      </div>
		<?php
				
				if(isset($_REQUEST['btnConfirm']))
				{
					mysql_query("update final_invoice set order_status='Delieved' where invoice_id='".$_REQUEST['invoiceID']."'");
					echo "<script>window.location='orderItem.php?invoiceID=$_REQUEST[invoiceID]'</script>";
				}
				
			?>
			<?php
				if(isset($_REQUEST['deleteID']))
				{
					mysql_query("delete from statement where st_id='".$_REQUEST['deleteID']."'");
					echo "<script>window.location='orderItem.php?invoiceID=$_REQUEST[invoiceID]'</script>";
				}
			?>			
</div>
</div>

	
</form>	
</body>
</html>